package com.example.covidinfo

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner

class FilterActivity : AppCompatActivity() {
    private lateinit var stateSpinner: Spinner
    private lateinit var ownershipSpinner: Spinner

    private var ownerships: ArrayList<String> = arrayListOf("Government","Trust","Society","University","Government-Society","Private")
    private var states: ArrayList<String> = arrayListOf("Telangana","Bihar","Tamil Nadu","Goa","Maharashtra","Chattisgarh","Rajasthan","Karnataka")

    private var filterState: String? = states[0]
    private var filterOwnership: String? = ownerships[0]

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_filter)
        title = "SEARCH HOSPITALS"

        stateSpinner = findViewById(R.id.stateSpinner)
        ownershipSpinner = findViewById(R.id.ownershipSpinner)

        val stateSpinnerAdapter = ArrayAdapter(this,R.layout.support_simple_spinner_dropdown_item,states)
        val ownershipSpinnerAdapter = ArrayAdapter(this,R.layout.support_simple_spinner_dropdown_item,ownerships)
        stateSpinner.adapter = stateSpinnerAdapter
        ownershipSpinner.adapter = ownershipSpinnerAdapter

        stateSpinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                filterState = states[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}

        }

        ownershipSpinner.onItemSelectedListener = object: AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                filterOwnership = ownerships[position]
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}

        }
    }

    fun applyFilter (view: View) {
        val intent: Intent = Intent()
        intent.putExtra("filterState",filterState)
        intent.putExtra("filterOwnership",filterOwnership)
        setResult(RESULT_OK,intent)
        finish()
    }
}