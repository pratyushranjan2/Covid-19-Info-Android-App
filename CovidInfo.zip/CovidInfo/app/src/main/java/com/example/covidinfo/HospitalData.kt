package com.example.covidinfo

class HospitalData (mstate: String, mruralHospitals: String,mruralBeds: String, murbanHospitals: String,murbanBeds: String, mtotalHospitals: String,mtotalBeds: String) {

    var state: String
    var ruralBeds: String
    var  ruralHospitals: String
    var urbanBeds: String
    var urbanHospitals: String
    var totalBeds: String
    var totalHospitals: String


    init {
        state = mstate
        ruralBeds = mruralBeds
        ruralHospitals = mruralHospitals
        urbanBeds = murbanBeds
        urbanHospitals = murbanHospitals
        totalBeds = mtotalBeds
        totalHospitals = mtotalHospitals
    }
}