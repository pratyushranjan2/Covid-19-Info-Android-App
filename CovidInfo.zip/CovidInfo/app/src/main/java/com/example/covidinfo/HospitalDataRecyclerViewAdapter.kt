package com.example.covidinfo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.hospital_data_list_item.view.*
import kotlinx.android.synthetic.main.notifications_list_item.view.*

class HospitalDataRecyclerViewAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var hospitalData: ArrayList<HospitalData> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return HospitalDataViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.hospital_data_list_item,parent,false)
        )
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is HospitalDataViewHolder -> {
                holder.bind(hospitalData[position].state, hospitalData[position].ruralHospitals, hospitalData[position].ruralBeds, hospitalData[position].urbanHospitals, hospitalData[position].urbanBeds, hospitalData[position].totalHospitals, hospitalData[position].totalBeds)
            }
        }
    }

    override fun getItemCount(): Int {
        return hospitalData.size
    }

    fun submitData (data: ArrayList<HospitalData>) {
        hospitalData = data
    }


    class HospitalDataViewHolder constructor(
        itemView: View
    ): RecyclerView.ViewHolder(itemView) {
        val stateTextView: TextView = itemView.hospital_data_state_textview as TextView
        val ruralHospitalTextView: TextView = itemView.hospital_data_rural_hospital_textview
        val ruralBedsTextView: TextView = itemView.hospital_data_rural_beds_textview as TextView
        val urbanHospitalTextView: TextView = itemView.hospital_data_urban_hospital_textview as TextView
        val urbanBedsTextView: TextView = itemView.hospital_data_urban_beds_textview as TextView
        val totalHospitalTextView: TextView = itemView.total_hospital_textview as TextView
        val totalBedsTextView: TextView = itemView.total_beds_textview as TextView
        fun bind (state: String, ruralHospitals: String, ruralBeds: String, urbanHospitals: String, urbanBeds: String, totalHospitals: String, totalBeds: String) {
            stateTextView.text = state
            ruralHospitalTextView.text = ruralHospitals
            ruralBedsTextView.text = ruralBeds
            urbanHospitalTextView.text = urbanHospitals
            urbanBedsTextView.text = urbanBeds
            totalHospitalTextView.text = totalHospitals
            totalBedsTextView.text = totalBeds
        }
    }

}