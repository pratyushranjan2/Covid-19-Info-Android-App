package com.example.covidinfo

import android.content.Intent
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import org.json.JSONArray
import org.json.JSONObject
import java.io.InputStreamReader
import java.lang.Exception
import java.net.HttpURLConnection
import java.net.URL
import javax.net.ssl.HttpsURLConnection

class MainActivity : AppCompatActivity() {
    private lateinit var filterImageView: ImageView
    private var filterState: String? = null
    private var filterOwnership: String? = null
    private var states: ArrayList<String> = ArrayList()
    private var contactNumbers: ArrayList<String> = ArrayList()
    private var notifications: ArrayList<String> = ArrayList()
    private var links: ArrayList<String> = ArrayList()
    private var dates: ArrayList<String> = ArrayList()
    private var hospitalData: ArrayList<HospitalData> = ArrayList()
    private lateinit var recyclerView: RecyclerView
    private lateinit var recyclerViewAdapter: RecyclerViewAdapter
    private lateinit var notificationsAdapter: NotificationsRecyclerViewAdapter
    private lateinit var hospitalDataAdapter: HospitalDataRecyclerViewAdapter
    private lateinit var bottomNavigation: BottomNavigationView
    private val helplineApiUrl: String = "https://api.rootnet.in/covid19-in/contacts"
    private val notificationsApiUrl: String = "https://api.rootnet.in/covid19-in/notifications"
    private val hospitalBedDataApiUrl: String = "https://api.rootnet.in/covid19-in/hospitals/beds"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        title = "STATE HELPLINE NUMBERS"

        filterImageView = findViewById(R.id.filter_imageview)

        recyclerView = findViewById(R.id.state_helpline_recyclerView)
        recyclerViewAdapter = RecyclerViewAdapter(this, states, contactNumbers)
        recyclerView.adapter = recyclerViewAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        notificationsAdapter = NotificationsRecyclerViewAdapter()
        notificationsAdapter.submitData(notifications,links,dates)
        hospitalDataAdapter = HospitalDataRecyclerViewAdapter()
        hospitalDataAdapter.submitData(hospitalData)


        loadHelplineData()
        //sampleData()


        bottomNavigation = findViewById(R.id.bottom_navigation)

        bottomNavigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.helpline_screen -> {
                    title = "STATE HELPLINE NUMBERS"
                    recyclerView.adapter = recyclerViewAdapter
                    filterImageView.visibility = View.INVISIBLE
                    filterImageView.isClickable = false
                    true
                }
                R.id.notification_screen -> {
                    title = "NOTIFICATIONS"
                    if (notifications.size == 0) {
                        loadNotificationsData()
                    }
                    recyclerView.adapter = notificationsAdapter
                    filterImageView.visibility = View.INVISIBLE
                    filterImageView.isClickable = false
                    true
                }
                R.id.hospital_data_screen -> {
                    title = "HOSPITALS AND BEDS"
                    if (hospitalData.size == 0) {
                        loadHospitalBedData()
                    }
                    recyclerView.adapter = hospitalDataAdapter
                    filterImageView.visibility = View.VISIBLE
                    filterImageView.isClickable = true
                    true
                }
                R.id.analytics_screen -> {
                    filterImageView.visibility = View.INVISIBLE
                    filterImageView.isClickable = false
                    true
                }
                else -> false
            }
        }

    }

    fun loadHelplineData () {
        val helplineApi: String? = downloadApi(helplineApiUrl)
        if (helplineApi != null) {
            extractHelplineApi(helplineApi)
        }
    }

    fun loadNotificationsData () {
        val notificationsApi: String? = downloadApi(notificationsApiUrl)
        if (notificationsApi != null) {
            extractNotificationsApi(notificationsApi)
        }
    }

    fun loadHospitalBedData () {
        val hospitalDataApi: String? = downloadApi(hospitalBedDataApiUrl)
        if (hospitalDataApi != null) {
            extractHospitalDataApi(hospitalDataApi)
        }
    }

    fun extractHospitalDataApi (api: String) {
        val jsonObject = JSONObject(api)
        try {
            val data: String = jsonObject.getString("data")
            val dataJsonObject = JSONObject(data)
            val regional: String = dataJsonObject.getString("regional")
            val regionalJsonArray = JSONArray(regional)

            for (i in 0 until regionalJsonArray.length()) {
                val dataObject = regionalJsonArray.getJSONObject(i)
                val state: String = dataObject.getString("state")
                val ruralHospitals: String = dataObject.getString("ruralHospitals")
                val ruralBeds: String = dataObject.getString("ruralBeds")
                val urbanHospitals: String = dataObject.getString("urbanHospitals")
                val urbanBeds: String = dataObject.getString("urbanBeds")
                val totalHospitals: String = dataObject.getString("totalHospitals")
                val totalBeds: String = dataObject.getString("totalBeds")
                hospitalData.add(HospitalData(state,"Rural Hospitals: $ruralHospitals","Rural Beds: $ruralBeds","Urban Hospitals: $urbanHospitals","Urban Beds: $urbanBeds","Total Hospitals: $totalHospitals","Total Beds: $totalBeds"))
                hospitalDataAdapter.notifyDataSetChanged()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.i("Info","API EXTRACTION UNSUCCESSFUL...3")
        }
    }

    fun extractNotificationsApi (api: String) {
        val jsonObject = JSONObject(api)
        try {
            val data: String = jsonObject.getString("data")
            val dataJsonObject = JSONObject(data)
            val mnotifications = dataJsonObject.getString("notifications")
            val notificationsJsonArray = JSONArray(mnotifications)

            for (i in 0 until notificationsJsonArray.length()) {
                val notificationDataObject = notificationsJsonArray.getJSONObject(i)
                val title: String = notificationDataObject.getString("title")
                if (title.length <12) {
                    continue
                }
                val date: String = title.substring(0..9)
                val link: String = notificationDataObject.getString("link")
                val notification = title.substring(11)
                notifications.add(notification)
                links.add(link)
                dates.add(date)
                notificationsAdapter.notifyDataSetChanged()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.i("Info","API EXTRACTION UNSUCCESSFUL...2")
        }
    }

    fun extractHelplineApi (api: String) {
        val jsonObject = JSONObject(api)
        try {
            val data: String = jsonObject.getString("data")
            val dataJsonObject = JSONObject(data)
            val contacts: String = dataJsonObject.getString("contacts")
            val contactsJsonObject = JSONObject(contacts)
            val regional: String = contactsJsonObject.getString("regional")
            val regionalJsonArray = JSONArray(regional)

            for (i in 0 until regionalJsonArray.length()) {
                val stateDataJsonObject = regionalJsonArray.getJSONObject(i)
                states.add(stateDataJsonObject.getString("loc"))
                contactNumbers.add(stateDataJsonObject.getString("number"))
                recyclerViewAdapter.notifyDataSetChanged()
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.i("Info","API EXTRACTION UNSUCCESSFUL...1")
        }
    }

    fun sampleData () {
        hospitalData.add(HospitalData("Bihar","Rural Hospitals: 234","Rural Beds: 300","Urban Hospitals: 1000","Urban Beds: 1234","Total Hospitals: 2302","Total Beds: 2345"))

        hospitalData.add(HospitalData("Bihar","Rural Hospitals: 234","Rural Beds: 300","Urban Hospitals: 1000","Urban Beds: 1234","Total Hospitals: 2302","Total Beds: 2345"))

        hospitalData.add(HospitalData("Bihar","Rural Hospitals: 234","Rural Beds: 300","Urban Hospitals: 1000","Urban Beds: 1234","Total Hospitals: 2302","Total Beds: 2345"))

        hospitalData.add(HospitalData("Bihar","Rural Hospitals: 234","Rural Beds: 300","Urban Hospitals: 1000","Urban Beds: 1234","Total Hospitals: 2302","Total Beds: 2345"))

        hospitalData.add(HospitalData("Bihar","Rural Hospitals: 234","Rural Beds: 300","Urban Hospitals: 1000","Urban Beds: 1234","Total Hospitals: 2302","Total Beds: 2345"))

    }

    fun downloadApi (url: String): String? {
        val task = DownloadTask()
        var returnApi: String? = null

        try {
            returnApi = task.execute(url).get()
            if (returnApi != null) {
                Log.i("Info",returnApi)
                return returnApi
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.i("Info","API DOWNLOAD UNSUCCESSFUL...")
        }
        return null
    }

    class DownloadTask : AsyncTask<String?, Void?, String?>() {
        override fun doInBackground(vararg params: String?): String? {
            var api: String? = ""
            try {
                val url = URL(params[0])
                val connection = url.openConnection() as HttpsURLConnection
                val inputStream = connection.inputStream
                val reader = InputStreamReader(inputStream)
                var data = reader.read()
                while (data != -1) {
                    val current = data.toChar()
                    api += current
                    data = reader.read()
                }
                return api
            } catch (e: java.lang.Exception) {
                e.printStackTrace()
            }
            return null
        }
    }

    fun directToFilterScreen(view: View) {
        val intent: Intent = Intent(this,FilterActivity::class.java)
        startActivityForResult(intent,1)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode==1 && resultCode== RESULT_OK) {
            filterState = data?.getStringExtra("filterState")
            filterOwnership = data?.getStringExtra("filterOwnership")
            Log.i("Filter State",filterState!!)
            Log.i("Filter Ownership",filterOwnership!!)
        }

        else {
            Log.i("Info","Filter Activity Intent Failed...")
        }
    }
}