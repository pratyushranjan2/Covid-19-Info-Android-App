package com.example.covidinfo

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.notifications_list_item.view.*

class NotificationsRecyclerViewAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var notifications: ArrayList<String> = ArrayList()
    private var links: ArrayList<String> = ArrayList()
    private var dates: ArrayList<String> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return NotificationsViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.notifications_list_item,parent,false)
        )
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when (holder) {
            is NotificationsViewHolder -> {
                holder.bind(notifications[position],links[position],dates[position])
            }
        }
    }

    override fun getItemCount(): Int {
        return notifications.size
    }

    fun submitData (notificationsList: ArrayList<String>, linksList: ArrayList<String>, notifyDates: ArrayList<String>) {
        notifications = notificationsList
        links = linksList
        dates = notifyDates
    }

    fun eraseData () {
        notifications.clear()
        links.clear()
    }

    class NotificationsViewHolder constructor(
        itemView: View
    ): RecyclerView.ViewHolder(itemView) {
        val notificationTextView: TextView = itemView.notification_textview as TextView
        val linkTextView: TextView = itemView.link_textview as TextView
        val dateTextView: TextView = itemView.date_textview as TextView
        fun bind (notification: String, link: String, date: String) {
            notificationTextView.text = notification
            linkTextView.text = link
            dateTextView.text = date
        }
    }

}