package com.example.covidinfo

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.RelativeLayout
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import java.util.*
import kotlin.collections.ArrayList


class RecyclerViewAdapter(context: Context, states: ArrayList<String>, contacts: ArrayList<String>) :
    RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder>() {
    private var mContext: Context
    private var mstates = ArrayList<String>()
    private var mcontacts = ArrayList<String>()
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view: View =
            LayoutInflater.from(parent.context).inflate(R.layout.helpline_list_item, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        Log.d("info", "onBindViewHolder called")
        holder.stateTextView.text = mstates[position]
        holder.contactTextView.text = mcontacts[position]
        holder.contactTextView.setOnClickListener {
            val number: String = "tel:"+holder.contactTextView.text.toString()
            val intent = Intent(Intent.ACTION_DIAL, Uri.parse(number))
            mContext.startActivity(intent)
        }
//        holder.parentLayout.setOnClickListener {
//            Toast.makeText(
//                mContext,
//                mTexts[position],
//                Toast.LENGTH_SHORT
//            ).show()
//        }
    }

    override fun getItemCount(): Int {
        return mstates.size
    }

    fun eraseData () {
        mstates.clear()
        mcontacts.clear()
    }

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var stateTextView: TextView
        var contactTextView: TextView
        var parentLayout: RelativeLayout

        init {
            parentLayout = itemView.findViewById(R.id.parent_layout)
            stateTextView = itemView.findViewById(R.id.helpline_state_textview)
            contactTextView = itemView.findViewById(R.id.helpline_state_number_textview)
        }
    }

    companion object {
        private const val TAG = "RecyclerViewAdapter" // for debugging, not so important
    }

    init {
        mContext = context
        mstates = states
        mcontacts = contacts
    }
}
